# Changelog

## 0.1.0 (2022-08-25)

* First release on PyPI.
