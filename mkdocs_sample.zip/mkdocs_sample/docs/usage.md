# Usage

To use zzl_mkdoc_sample in a project

```
import zzl_mkdoc_sample
```
