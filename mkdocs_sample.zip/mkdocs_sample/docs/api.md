::: zzl_mkdoc_sample
