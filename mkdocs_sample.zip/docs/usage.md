# Usage

To use zzl_mkdoc_sample in a project

```
import zzl_mkdoc_sample
```

!!! note "Note"
	Hello, this is note.
    
    What do you want to write it here?

!!! info "info"
	This is info. 
	
!!! solution "solution"
	This is solution.
	
!!! exercise "exercise"
	This is exercise.
	
!!! warning "warning"
	This is warning.
	
!!! error "error"
	This is error.