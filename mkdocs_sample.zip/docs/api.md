::: mkdoc_sample
