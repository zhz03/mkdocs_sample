"""Top-level package for zzl_mkdoc_sample."""

__author__ = """Zhaoliang Zheng"""
__email__ = 'zhz03@g.ucla.edu'
__version__ = '0.1.0'
